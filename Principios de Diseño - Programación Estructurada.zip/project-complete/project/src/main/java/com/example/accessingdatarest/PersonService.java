package com.example.accessingdatarest;

import java.util.List;
import java.util.Optional;

/**
 * Interfaz de servicio para operaciones sobre Person.
 *
 * El PATRÓN PROXY se aplica aquí:
 * - Esta interfaz define el contrato.
 * - PersonProxy implementa la interfaz e intercepta las llamadas
 *   para añadir caché manual antes/después de delegar al repositorio.
 */
public interface PersonService {

    /**
     * Retorna todas las personas.
     */
    List<Person> findAll();

    /**
     * Retorna una persona por su ID.
     */
    Optional<Person> findById(Long id);

    /**
     * Busca personas por apellido.
     */
    List<Person> findByLastName(String lastName);

    /**
     * Guarda (crea o actualiza) una persona.
     */
    Person save(Person person);

    /**
     * Elimina una persona por ID.
     */
    void deleteById(Long id);
}
