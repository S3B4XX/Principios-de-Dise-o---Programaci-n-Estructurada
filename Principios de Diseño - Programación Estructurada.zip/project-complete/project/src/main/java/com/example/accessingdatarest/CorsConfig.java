package com.example.accessingdatarest;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

/**
 * Configuración CORS (Cross-Origin Resource Sharing).
 *
 * PROBLEMA EN DESARROLLO:
 * El frontend corre en un origen diferente al backend
 * (ej: frontend en localhost:3000, backend en localhost:9090).
 * El navegador bloquea estas peticiones por seguridad (política Same-Origin).
 *
 * SOLUCIÓN:
 * Se le dice al backend que acepte peticiones desde cualquier origen (*).
 * Esto es seguro en desarrollo. En producción se debería
 * restringir a orígenes específicos.
 *
 * Esta clase aplica CORS tanto para los endpoints de Spring Data REST (/people)
 * como para los endpoints del controlador personalizado (/api/people).
 */
@Configuration
public class CorsConfig implements RepositoryRestConfigurer {

    /**
     * CORS para endpoints de Spring Data REST (ej: /people).
     */
    @Override
    public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config,
                                                     CorsRegistry cors) {
        cors.addMapping("/**")
            .allowedOrigins("*")
            .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
            .allowedHeaders("*");
    }
}
