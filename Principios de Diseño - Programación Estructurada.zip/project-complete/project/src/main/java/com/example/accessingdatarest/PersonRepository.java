package com.example.accessingdatarest;

import java.util.List;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

/**
 * Repositorio Spring Data REST.
 *
 * Expone automáticamente endpoints REST en /people (HAL+JSON).
 *
 * CACHÉ con Spring:
 * - @Cacheable: si el resultado ya está en caché, no va a la BD.
 * - @CacheEvict: cuando se guarda o borra, limpia la caché para
 *   que los próximos reads vean datos frescos.
 */
@RepositoryRestResource(collectionResourceRel = "people", path = "people")
public interface PersonRepository
        extends PagingAndSortingRepository<Person, Long>,
                CrudRepository<Person, Long> {

    /**
     * Busca personas por apellido.
     * El resultado se guarda en caché "people".
     */
    @Cacheable("people")
    List<Person> findByLastName(@Param("name") String name);

    /**
     * Retorna todos los registros.
     * El resultado se guarda en caché "people".
     */
    @Override
    @Cacheable("people")
    Iterable<Person> findAll();

    /**
     * Guarda (crea o actualiza) una persona.
     * Invalida toda la caché "people" para mantener consistencia.
     */
    @Override
    @CacheEvict(value = "people", allEntries = true)
    <S extends Person> S save(S entity);

    /**
     * Elimina una persona por ID.
     * Invalida toda la caché "people".
     */
    @Override
    @CacheEvict(value = "people", allEntries = true)
    void deleteById(Long id);
}
