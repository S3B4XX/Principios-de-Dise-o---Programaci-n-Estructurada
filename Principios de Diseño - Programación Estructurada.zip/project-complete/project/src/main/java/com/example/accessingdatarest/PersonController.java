package com.example.accessingdatarest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * Controlador REST que expone el endpoint /api/people.
 *
 * NO habla con el repositorio directamente.
 * Habla con PersonService (que en runtime es PersonProxy).
 * Así el controlador no sabe si hay caché o no → transparencia total.
 */
@RestController
@RequestMapping("/api/people")
public class PersonController {

    // Se inyecta PersonProxy (que implementa PersonService)
    private final PersonService personService;

    public PersonController(PersonService personService) {
        this.personService = personService;
    }

    /**
     * GET /api/people
     * Retorna todas las personas.
     */
    @GetMapping
    public List<Person> getAll() {
        return personService.findAll();
    }

    /**
     * GET /api/people/{id}
     * Retorna una persona por ID o 404 si no existe.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Person> getById(@PathVariable Long id) {
        Optional<Person> person = personService.findById(id);
        return person.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/people/search?lastName=Doe
     * Busca personas por apellido.
     */
    @GetMapping("/search")
    public List<Person> search(@RequestParam String lastName) {
        return personService.findByLastName(lastName);
    }

    /**
     * POST /api/people
     * Crea una nueva persona.
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Person create(@RequestBody Person person) {
        return personService.save(person);
    }

    /**
     * PUT /api/people/{id}
     * Actualiza una persona existente.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Person> update(@PathVariable Long id,
                                         @RequestBody Person body) {
        Optional<Person> existing = personService.findById(id);
        if (existing.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Person person = existing.get();
        person.setFirstName(body.getFirstName());
        person.setLastName(body.getLastName());
        return ResponseEntity.ok(personService.save(person));
    }

    /**
     * DELETE /api/people/{id}
     * Elimina una persona.
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (personService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        personService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
