package com.example.accessingdatarest;

import java.util.HashMap;
import java.util.Map;

/**
 * PATRÓN SINGLETON — Caché manual en memoria.
 *
 * Solo existe UNA instancia de esta clase durante toda la ejecución
 * de la aplicación. Se accede a ella siempre mediante getCache().
 *
 * Almacena pares clave-valor (String → String).
 * El PersonProxy la usa para guardar respuestas serializadas como JSON.
 */
public class Cache {

    // Instancia única (Singleton)
    private static Cache localCache;

    // Mapa interno que almacena los datos cacheados
    private static Map<String, String> keyMap;

    // Constructor privado: nadie puede instanciar esta clase desde afuera
    private Cache() {
        keyMap = new HashMap<>();
    }

    /**
     * Punto de acceso global a la instancia única.
     * Si no existe, la crea (lazy initialization).
     */
    public static Cache getCache() {
        if (localCache == null) {
            localCache = new Cache();
        }
        return localCache;
    }

    /**
     * Guarda un valor en la caché bajo una clave.
     */
    public static void setCacheValue(String key, String val) {
        keyMap.put(key, val);
    }

    /**
     * Recupera un valor de la caché por su clave.
     * Retorna null si no existe.
     */
    public static String getCacheValue(String key) {
        return keyMap.get(key);
    }

    /**
     * Elimina una entrada específica de la caché.
     */
    public static void evict(String key) {
        keyMap.remove(key);
    }

    /**
     * Limpia toda la caché.
     */
    public static void evictAll() {
        keyMap.clear();
    }
}
