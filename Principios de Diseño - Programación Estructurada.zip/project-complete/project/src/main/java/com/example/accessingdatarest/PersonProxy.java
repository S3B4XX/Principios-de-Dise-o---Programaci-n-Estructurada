package com.example.accessingdatarest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * PATRÓN PROXY — PersonProxy actúa como intermediario entre el
 * controlador REST y el repositorio (PersonRepository).
 *
 * ¿Qué hace el proxy aquí?
 * 1. Intercepta la llamada del cliente.
 * 2. Revisa si el resultado ya está en la caché manual (Cache).
 * 3. Si está en caché → devuelve el dato sin ir a la base de datos.
 * 4. Si NO está → delega al repositorio real, guarda el resultado
 *    en caché y lo devuelve.
 * 5. En operaciones de escritura (save/delete) → invalida la caché
 *    para que los datos no queden obsoletos.
 *
 * El cliente (PersonController) solo conoce la interfaz PersonService,
 * no sabe si habla con el proxy o con el repositorio directamente.
 */
@Service
public class PersonProxy implements PersonService {

    // Repositorio real al que el proxy delega cuando es necesario
    private final PersonRepository repository;

    // ObjectMapper de Jackson para serializar/deserializar a JSON
    private final ObjectMapper objectMapper;

    // Clave usada en la caché para almacenar la lista completa
    private static final String ALL_KEY = "all_people";

    public PersonProxy(PersonRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper  = objectMapper;
        // Inicializar el Singleton de Cache
        Cache.getCache();
    }

    /**
     * Retorna todas las personas.
     * Primero revisa la caché; si no hay dato, va a la BD.
     */
    @Override
    public List<Person> findAll() {
        // 1. Revisar caché
        String cached = Cache.getCacheValue(ALL_KEY);
        if (cached != null) {
            System.out.println("[PROXY] HIT caché → findAll()");
            return deserialize(cached);
        }

        // 2. No hay caché → ir al repositorio
        System.out.println("[PROXY] MISS caché → consultando BD para findAll()");
        List<Person> people = new ArrayList<>();
        repository.findAll().forEach(people::add);

        // 3. Guardar en caché para próximas llamadas
        Cache.setCacheValue(ALL_KEY, serialize(people));

        return people;
    }

    /**
     * Retorna una persona por ID.
     * Usa una clave individual en la caché.
     */
    @Override
    public Optional<Person> findById(Long id) {
        String key = "person_" + id;

        // 1. Revisar caché
        String cached = Cache.getCacheValue(key);
        if (cached != null) {
            System.out.println("[PROXY] HIT caché → findById(" + id + ")");
            try {
                return Optional.of(objectMapper.readValue(cached, Person.class));
            } catch (Exception e) {
                System.err.println("[PROXY] Error deserializando persona: " + e.getMessage());
            }
        }

        // 2. Ir al repositorio
        System.out.println("[PROXY] MISS caché → consultando BD para findById(" + id + ")");
        Optional<Person> person = repository.findById(id);

        // 3. Guardar en caché si existe
        person.ifPresent(p -> Cache.setCacheValue(key, serialize(p)));

        return person;
    }

    /**
     * Busca por apellido.
     */
    @Override
    public List<Person> findByLastName(String lastName) {
        String key = "lastName_" + lastName;

        String cached = Cache.getCacheValue(key);
        if (cached != null) {
            System.out.println("[PROXY] HIT caché → findByLastName(" + lastName + ")");
            return deserialize(cached);
        }

        System.out.println("[PROXY] MISS caché → consultando BD para findByLastName(" + lastName + ")");
        List<Person> people = repository.findByLastName(lastName);
        Cache.setCacheValue(key, serialize(people));
        return people;
    }

    /**
     * Guarda una persona e invalida la caché entera.
     */
    @Override
    public Person save(Person person) {
        System.out.println("[PROXY] save() → invalidando caché completa");
        Person saved = repository.save(person);
        Cache.evictAll(); // Los datos cambiaron → limpiar todo
        return saved;
    }

    /**
     * Elimina una persona por ID e invalida la caché entera.
     */
    @Override
    public void deleteById(Long id) {
        System.out.println("[PROXY] deleteById(" + id + ") → invalidando caché completa");
        repository.deleteById(id);
        Cache.evictAll(); // Los datos cambiaron → limpiar todo
    }

    // ─── Helpers de serialización ───────────────────────────────────

    private String serialize(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            System.err.println("[PROXY] Error serializando: " + e.getMessage());
            return "[]";
        }
    }

    private List<Person> deserialize(String json) {
        try {
            return objectMapper.readValue(json, new TypeReference<List<Person>>() {});
        } catch (Exception e) {
            System.err.println("[PROXY] Error deserializando lista: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
